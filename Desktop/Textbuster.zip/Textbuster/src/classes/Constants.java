package classes;

public class Constants {
	
	//Storing the Userstatus statically
	
	public static UserStatus myUserStatus;

}
