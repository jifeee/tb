package com.access2;


import com.access2.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.Button;
import android.widget.EditText;

public class SetupPasswordActivity extends Activity {
	
	String TAG="TEX";
	Context ctx;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pagesix);
		ctx=this;

		final Button confirm = (Button)findViewById(R.id.button1);
		
        final EditText email = (EditText) findViewById(R.id.editText1);
        email.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                 
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                    (keyCode == KeyEvent.KEYCODE_ENTER)) {
                   
                	findViewById(R.id.editText2).requestFocus();
                  return true;
                }
                return false;
            }
        });
        
        
        final EditText pass = (EditText) findViewById(R.id.editText2);
        pass.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                 
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                    (keyCode == KeyEvent.KEYCODE_ENTER)) {
                   
                	findViewById(R.id.editText3).requestFocus();
                  return true;
                }
                return false;
            }
        });
        
        
        
        final EditText passrep = (EditText) findViewById(R.id.editText3);
        passrep.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                 
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                    (keyCode == KeyEvent.KEYCODE_ENTER)) {
                   
                	findViewById(R.id.button1).requestFocus();
                  return true;
                }
                return false;
            }
        });

        
        confirm.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {   
            		String e = email.getText().toString();
            		String p = pass.getText().toString();
            		String pr = passrep.getText().toString();
            		
            		if (p.equals(pr)) {
            			Log.i(TAG, "Passwords match");
            		}
            		
            		else {
            			showAlert();
            		}

        		}
            });
		
	}
	
	public void showAlert() {
		final AlertDialog ad = new AlertDialog.Builder(ctx).create();
		ad.setTitle("Error");
		ad.setMessage("The passwords do not match.");
		ad.setButton("OK", new DialogInterface.OnClickListener() {
	  	      public void onClick(DialogInterface dialog, int which) {
	  	    	  ad.dismiss();
	  	    	  
	  	    } }); 
	  	 
	  	ad.show();
	}

}
