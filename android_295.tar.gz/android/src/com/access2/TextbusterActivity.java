package com.access2;

import java.util.Iterator;

import com.access2.R;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.ToggleButton;

public class TextbusterActivity extends Activity {
	private static final String TAG = "TEX";
	IntentFilter filter = new IntentFilter();
	BluetoothAdapter bt = BluetoothAdapter.getDefaultAdapter();
	BluetoothDevice textbuster;
	ProgressBar pb;
	ToggleButton toggle;
	Button pairButton;
	TextView tv1;
	TextView tv2;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Intent loginIntent = new Intent(TextbusterActivity.this, DetectActivity.class);      
    	TextbusterActivity.this.startActivityForResult(loginIntent, 0);   
        
      
//        Intent service = null;
//        
//        Context ctx = this.getBaseContext();
//        
//        service = new Intent(ctx, TextbusterService.class);
//        
//        ctx.startService(service);
        
        

         
        
    }
    
    protected void onDestroy() {
		Log.i(TAG, "destroy");
		
		super.onDestroy();
	}
	public void onPause()
	  {
		Log.i(TAG, "pause");
	    
	    super.onPause();
	  }

	 public void onResume()
	  {
		 Log.i(TAG, "resume");
	    
	    super.onResume();
	  }


}
        

        
//        
    
