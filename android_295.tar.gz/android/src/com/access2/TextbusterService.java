package com.access2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import classes.Logger;
import classes.Reporter;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.telephony.TelephonyManager;
import android.util.Log;

public class TextbusterService extends Service{
	private static final String TAG = "TEX";
	private Context context;
	private String aclCallbackId = null;
	
	private volatile BluetoothAdapter bluetoothAdapter;
	
	final Handler nextAddressHandler = new Handler();
	final Handler closeRfcommHandler = new Handler();
	final Handler checkLockHandler = new Handler();
	
	private BluetoothSocket rfcommSocket = null;
	BluetoothDevice bluetoothDevice = null; 
	
	private ArrayList<String> macAddresses = new ArrayList();
	
	private int lockCheckInterval = 1;
	private int lockInterval = 40;
	private int discoveryInterval = 120;
	private int discoveryDelay = 60;
	private int closeRfcommInterval = 15;

	private boolean locked = false; 
	private boolean lockedByBT = false;
	private boolean lockedByTB = false;
	
	private long lastACL = 0;
	
	PowerManager pm;
	
	
	private Reporter reporter = null;
	
	public void onCreate(){
		
		context=this; 
		
		reporter = new Reporter(this);
		
		setupReceivers();
		
		new Timer().scheduleAtFixedRate(mainloop, 0, lockCheckInterval*1000);
		
		pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		
		Logger myLogger = new Logger();
		
		reporter.checkForLocation();
		reporter.getLocation();
		
		TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
//		Log.i(TAG, "IMEI: " + telephonyManager.getDeviceId());
		
	}
	
	private TimerTask mainloop = new TimerTask(){ 
		public void run(){
		
//			boolean isScreenOn = pm.isScreenOn();
			boolean isScreenOn = true; 
//			Log.i(TAG, "running");
			
			
			
			if (isScreenOn==true) {
				
//				rfcommSocket=null;
				
				checkBTlock();
				
				checkTBlock();
	
				connect();
				
//				Log.i(TAG, "by BT: " + lockedByBT + " by TB: " + lockedByTB);
				
			}

			
		}
	};
	
	public void connect () {
		long sinceLastACL = new Date().getTime() - lastACL;
		if(sinceLastACL < discoveryDelay * 1000){
//			Log.i(TAG, sinceLastACL/1000 + " since last connection");
		}
		
		else {
			if(rfcommSocket == null){
				
				try{
					String mac = "00:12:A1:C8:00:06";
//					Log.d(TAG, "Trying to connect to " + mac);
					
					bluetoothDevice = bluetoothAdapter.getRemoteDevice(mac);
					final BluetoothSocket bluetoothSocket = rfcommSocket = bluetoothDevice.
					
							createRfcommSocketToServiceRecord(new java.util.UUID(0x0000110100001000L, 0x800000805F9B34FBL));
					
//					Log.i(TAG, "BTA status: " + bluetoothAdapter.getState() + " " + bluetoothAdapter.getScanMode() + " " + 
//							bluetoothAdapter.toString());
					
					bluetoothSocket.connect();
					
				}catch(IOException e){
//					Log.d(TAG, "IO Exception: " + e.getMessage());
					
					rfcommSocket = null;
				}finally{
				}
			}
		}

	}
	
	private void checkBTlock () {
		if(reporter.getBluetoothState() < Reporter.BLUETOOTH_ON ){
			lockedByBT=true;  
			lock(LockActivity.LOCK_BLUETOOTH);
			
		}	
		
		else {
			lockedByBT = false; 
			if (locked==false) {
				unlock();
			}
		}
	}
	
	
	private void checkTBlock() {
		
		long sinceLastACL = new Date().getTime() - lastACL;
	
		if(sinceLastACL <= lockInterval * 1000){
			lockedByTB=true; 
			locked=true; 
			lock(LockActivity.LOCK_TEXTBUSTER);
//			Log.d(TAG, "locked: true");

		}
		
		if(sinceLastACL > lockInterval * 1000) {
			lockedByTB=false; 
			if (lockedByBT==false) {
				unlock();
			}
			
			else {
			
				
			}
		}
		
		
		else if(sinceLastACL > lockInterval * 1000 && locked == true){
			
					unlock();
				
//				Log.d(TAG, "unlock from checklock");

		}
		
		else {
//			Log.i(TAG, "none");
		}
	}
	
	private void lock(int type){
		
//		Log.i(TAG, "lock, type: " + type);
		
		if(reporter.getTopActivity().equals(LockActivity.class.getName())) {

//			Log.d(TAG, "Lock already engaged");
		}else{
			
//			Log.i(TAG, "new Lockscreen");
			
			Intent intent = new Intent(getApplicationContext(), LockActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
							Intent.FLAG_ACTIVITY_NO_HISTORY |
							Intent.FLAG_ACTIVITY_REORDER_TO_FRONT |
							Intent.FLAG_ACTIVITY_SINGLE_TOP);
			intent.putExtra("type", type);
			startActivity(intent);
		}
	}
	
	private void unlock(){
//		Log.i(TAG, "unlock");
		Intent i = new Intent();
		i.setAction(LockActivity.BROADCAST_UNLOCK);
        getApplicationContext().sendBroadcast(i);
		
	}
	
	public IBinder onBind(Intent intent) {
		
		return null;
	}
	
	public void setupReceivers () {
		final BroadcastReceiver aclReceiver = new BroadcastReceiver() {
		    public void onReceive(Context context, Intent intent) {
//		    	Log.i(TAG, "onreceive aclReceiver");
		        String action = intent.getAction();
		        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
				String address = device.toString();
				
				String event = "ACUN";
				
				if(action.equals(BluetoothDevice.ACTION_ACL_CONNECTED)){
					event = "ACCN";
//					Log.d(TAG, "ACL connected from " + address);
					lastACL = new Date().getTime();
					lock(LockActivity.LOCK_TEXTBUSTER);
				} else if(action.equals(BluetoothDevice.ACTION_ACL_DISCONNECTED)){
					event = "ACDC";
//					Log.d(TAG, "ACL disconnected from " + address);
					
					if(rfcommSocket != null && rfcommSocket.getRemoteDevice().getAddress().equals(address)){
						rfcommSocket = null;
					lastACL = new Date().getTime();
					}
					
					lastACL = new Date().getTime();
				} else if(action.equals(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED)){
					event = "ACDR";
//					Log.d(TAG, "ACL disconnect requested from " + address);
				}

			}
		};

		/* Reveives events related to the Android's Bluetooth device.
		 */
		final BroadcastReceiver btReceiver = new BroadcastReceiver() {
		    public void onReceive(Context context, Intent intent) {
//		    	Log.i(TAG, "onreceive btReceiver");
		        String action = intent.getAction();
		        String event = "UN";
				
				if(action.equals(BluetoothAdapter.ACTION_DISCOVERY_STARTED)){
					event = "BTDS";
//					Log.d(TAG, "Discovery started");
				} else if(action.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)){
					event = "BTDF";
//					Log.d(TAG, "Discovery finished");
				}

			}
		};
		
		bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		
		IntentFilter filter = new IntentFilter();
		filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
		filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
		filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED);
		context.registerReceiver(aclReceiver, filter);
		
		filter = new IntentFilter();
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		context.registerReceiver(btReceiver, filter);
	}
}
