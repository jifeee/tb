package data;

import java.util.ArrayList;

public class MAC {
	
	private ArrayList <String> knownMACs = new ArrayList <String> ();


}
